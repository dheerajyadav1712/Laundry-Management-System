# laundry management system

---
## Using Tech:

* Php
* JavaScript
* MySql
* JQuery
* Ajax
* Bootstarp
* HTML5
* CSS3


---
#### Watch Demo : https://www.youtube.com/watch?v=ReipY-Eg9YY
---
## Features

*	Add/delete/claim customer details with priority, weight, and types 
*	You can add laundry type and amount
*	You can generate of whole or specific report
*	You can change password and can logout


---


## Author Info
- Linkedin- [@Mohaiminur](https://www.linkedin.com/in/mohaiminur/)
- Youtube- [@Mohaiminur](https://www.youtube.com/channel/UC5MlwVt5vXtpHvgDHxbgqmw)
- Facebook- [@Mohaiminur](https://facebook.com/mohaiminur404)
- Twitter - [@Mohaiminur](https://twitter.com/mohaiminur404)
- Website - [Mohaiminur](https://mohaiminur.ml)

---
